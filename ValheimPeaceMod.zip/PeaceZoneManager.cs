using System.Collections.Generic;
using BepInEx.Logging;
using UnityEngine;

namespace ValheimPeaceMod
{
    internal struct PeaceZone
    {
        public ZDOID StandId;
        public Vector3 Position;
        public Heightmap.Biome Biome;
    }

    /// <summary>
    /// Static registry of every currently-active peace zone (one per item
    /// stand that has a boss trophy mounted on it). Requirement 1/2/5 live here;
    /// requirement 3 (raid boost) and requirement 4 (message) just read/react
    /// to this state from their own patches.
    /// </summary>
    internal static class PeaceZoneManager
    {
        private static readonly Dictionary<ZDOID, PeaceZone> Zones = new Dictionary<ZDOID, PeaceZone>();

        public static void RegisterZone(ZDOID standId, Vector3 position, Heightmap.Biome biome, ManualLogSource log)
        {
            var isNew = !Zones.ContainsKey(standId);

            Zones[standId] = new PeaceZone
            {
                StandId = standId,
                Position = position,
                Biome = biome
            };

            if (isNew)
            {
                log?.LogInfo($"[ValheimPeaceMod] Peace zone activated for {biome} at {position} (stand {standId}).");
            }
        }

        public static void UnregisterZone(ZDOID standId, ManualLogSource log)
        {
            if (Zones.Remove(standId))
            {
                log?.LogInfo($"[ValheimPeaceMod] Peace zone removed for stand {standId}.");
            }
        }

        public static void Clear()
        {
            Zones.Clear();
        }

        public static int ActiveZoneCount => Zones.Count;

        /// <summary>
        /// True if the given world position, known to be in the given biome,
        /// falls inside any active peace zone for that same biome.
        /// </summary>
        public static bool IsPeaceful(Vector3 position, Heightmap.Biome biome)
        {
            var radius = Config.NoSpawnRadius.Value;

            foreach (var zone in Zones.Values)
            {
                if (zone.Biome != biome) continue;

                // Cheap squared-distance check before sqrt.
                var sqrRadius = radius * radius;
                if ((zone.Position - position).sqrMagnitude <= sqrRadius)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// True if raid spawns in this biome should be boosted, i.e. at least
        /// one peace zone exists for the biome the raid position falls in.
        /// Reuses the same radius/zone data as IsPeaceful - "that biome" per
        /// requirement 3 means the biome whose boss trophy is mounted.
        /// </summary>
        public static bool IsRaidBoosted(Vector3 position, Heightmap.Biome biome)
        {
            return IsPeaceful(position, biome);
        }

        /// <summary>
        /// Safety-net rescan: finds every currently loaded ItemStand, checks what
        /// (if anything) is visually attached to it, and rebuilds zone state from
        /// scratch. Loaded-only is fine here because ambient spawning likewise
        /// only happens in currently active/loaded zones near players.
        /// </summary>
        public static void RescanLoadedStands(ManualLogSource log)
        {
            var stands = Object.FindObjectsOfType<ItemStand>();

            foreach (var stand in stands)
            {
                var nview = stand.GetComponent<ZNetView>();
                if (nview == null || !nview.IsValid()) continue;

                var id = nview.GetZDO().m_uid;

                var attachedName = ItemStandInterop.GetAttachedItemName(stand);
                if (BossTrophyData.TryGetBiome(attachedName, out var biome))
                {
                    RegisterZone(id, stand.transform.position, biome, log);
                }
                else
                {
                    UnregisterZone(id, log);
                }
            }

            // Deliberately not pruning zones for stands outside the currently
            // loaded area: a peace zone should persist while its owning zone
            // is simply unloaded, not just while a player stands next to it.
            // The genuine "trophy removed" case is caught immediately by the
            // ItemStandPatches hook, and destroyed stands go through the
            // same SetVisualItem("") path or a piece-destroyed patch below.
        }
    }
}

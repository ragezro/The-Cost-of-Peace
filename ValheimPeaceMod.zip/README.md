# ValheimPeaceMod

A BepInEx/Harmony mod for Valheim: mounting a boss trophy on an item stand
pacifies that boss's biome against ambient spawns within a configurable
radius, while raids in that biome keep happening but with more spawns.

## Requirements -> implementation map

1. **No ambient spawns near a mounted boss trophy, radius 10f-1000f, repeatable**
   `Patches/SpawnPatches.cs` prefixes `SpawnSystem.Spawn`. When the spawn is
   not an event/raid creature and its position+biome falls inside an active
   `PeaceZone` (tracked in `PeaceZoneManager`), the prefix returns `false` and
   the original spawn never happens. `Config.NoSpawnRadius` is clamped
   10f-1000f. This applies every time a trophy is (re-)mounted, indefinitely.

2. **Stacks per biome as more bosses are defeated**
   `PeaceZoneManager` keys zones by the item stand's `ZDOID`, so each stand
   with a boss trophy gets its own independent zone. Nothing about mounting
   one boss's trophy affects another biome's zone.

3. **Raids still occur but with 1.5x-10x the spawns**
   Same `SpawnSystem.Spawn` method also handles event/raid creatures, flagged
   via its `eventCreature` parameter. The postfix in `SpawnPatches.cs` checks
   `eventCreature == true`; if the raid spawn lands inside an active peace
   zone's biome, it re-invokes `Spawn` extra times to reach
   `Config.RaidSpawnMultiplier` (clamped 1.5-10), with the fractional part of
   the multiplier applied probabilistically.

4. **"Peace has come!" center-screen message on mount**
   `Patches/ItemStandPatches.cs` postfixes `ItemStand.SetVisualItem`; when a
   name matching a configured boss trophy is attached, it calls
   `MessageHud.instance.ShowMessage(MessageHud.MessageType.Center, ...)`.
   Text is configurable via `Config.PeaceMessage`.

5. **Removing the trophy ends the no-spawn zone**
   The same `SetVisualItem` postfix fires with an empty `name` on removal and
   calls `PeaceZoneManager.UnregisterZone`. There's also an `OnDestroy` hook
   so destroying the stand outright doesn't leave a dangling zone.

## IMPORTANT: verify against your game version before building

I wrote this against the well-known, stable parts of Valheim's modding
surface, but two things are private game internals that **do** drift between
patches and need a quick check in dnSpy against your own
`assembly_valheim.dll` (Steam > Valheim > right-click > Manage > Browse local
files > `valheim_Data/Managed/assembly_valheim.dll`):

- **`SpawnSystem.Spawn`** (`Patches/SpawnPatches.cs`) - confirm the method
  name and parameter list (`SpawnData`, `Vector3Int`, `Heightmap`, `bool
  eventCreature`, `ZoneSystem.ZoneVegetation`). This is the one load-bearing
  patch; if it doesn't bind, the mod logs an error at startup and does
  nothing rather than crashing.
- **`ItemStand.SetVisualItem`** (`Patches/ItemStandPatches.cs`) and the ZDO
  key it stores the attached item under (`ItemStandInterop.cs`, currently
  `"item"`) - confirm both by searching `ItemStand` in dnSpy.

Both patch appliers (`SpawnPatches.Apply`, `ItemStandPatches.Apply`) are
written to log a clear warning/error and skip gracefully instead of throwing
if a signature doesn't match, so a mismatch won't take down your whole
BepInEx load order - check your `LogOutput.log` on first launch.

## Building

1. Install .NET SDK (matching `netstandard2.1`) and set an environment
   variable `VALHEIM_INSTALL` pointing at your Valheim install folder (the
   one containing `valheim_Data\Managed`).
2. `dotnet build -c Release`
3. Copy the built `ValheimPeaceMod.dll` into
   `BepInEx/plugins/ValheimPeaceMod/` on both server and clients (this is
   server-authoritative logic - the server needs it; clients need it too so
   the peace message shows and their locally-run `SpawnSystem` agrees).

## Configuration

Generated at `BepInEx/config/com.yourname.valheimpeacemod.cfg` after first
launch:

- `General.ModEnabled` (bool)
- `General.PeaceMessage` (string) - default `"Peace has come!"`
- `PeaceZone.NoSpawnRadius` (float, 10-1000) - default `500`
- `PeaceZone.RaidSpawnMultiplier` (float, 1.5-10) - default `2`
- `Advanced.ZoneRescanIntervalSeconds` (float, 1-60) - default `5`
- `BossTrophies.TrophyToBiomeMap` (string) - `TrophyName:Biome` pairs, comma
  separated, pre-filled with the vanilla bosses through Ashlands. Extend this
  if a future update adds a boss/biome, without needing a code change.

## Multiplayer notes

`ItemStand.SetVisualItem` and the item stand's ZDO are synced by the game
itself, so every client independently reconstructs the same peace-zone state
and applies the same spawn suppression/boost locally - there's no custom
networking in this mod. The periodic rescan in `Plugin.cs` is a safety net in
case a client joins mid-session after an attach event already happened.

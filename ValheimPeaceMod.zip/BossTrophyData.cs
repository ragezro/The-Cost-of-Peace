using System;
using System.Collections.Generic;
using BepInEx.Logging;

namespace ValheimPeaceMod
{
    /// <summary>
    /// Resolves an attached item-stand item name to the biome it should pacify,
    /// based on Config.BossTrophyBiomeMap. Rebuilt once and cached; call
    /// Refresh() if the config value changes at runtime (e.g. config-reload).
    /// </summary>
    internal static class BossTrophyData
    {
        private static Dictionary<string, Heightmap.Biome> _map;

        public static void Refresh(ManualLogSource log)
        {
            _map = new Dictionary<string, Heightmap.Biome>(StringComparer.OrdinalIgnoreCase);

            var raw = Config.BossTrophyBiomeMap.Value;
            if (string.IsNullOrWhiteSpace(raw))
            {
                return;
            }

            foreach (var entry in raw.Split(','))
            {
                var trimmed = entry.Trim();
                if (trimmed.Length == 0) continue;

                var parts = trimmed.Split(':');
                if (parts.Length != 2)
                {
                    log?.LogWarning($"[ValheimPeaceMod] Skipping malformed trophy map entry '{trimmed}'. Expected TrophyName:Biome.");
                    continue;
                }

                var trophyName = parts[0].Trim();
                var biomeName = parts[1].Trim();

                if (!Enum.TryParse<Heightmap.Biome>(biomeName, true, out var biome))
                {
                    log?.LogWarning($"[ValheimPeaceMod] Unknown biome '{biomeName}' for trophy '{trophyName}'. Skipping.");
                    continue;
                }

                _map[trophyName] = biome;
            }
        }

        public static bool TryGetBiome(string trophyItemName, out Heightmap.Biome biome)
        {
            if (_map == null)
            {
                Refresh(null);
            }

            if (string.IsNullOrEmpty(trophyItemName))
            {
                biome = default;
                return false;
            }

            return _map.TryGetValue(trophyItemName, out biome);
        }
    }
}

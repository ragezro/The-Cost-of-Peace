using BepInEx;
using BepInEx.Configuration;

namespace ValheimPeaceMod
{
    /// <summary>
    /// Centralizes every configurable value the mod exposes. Bound once in
    /// Plugin.Awake() and read from anywhere via Config.* static accessors.
    /// </summary>
    internal static class Config
    {
        public static ConfigEntry<bool> ModEnabled;
        public static ConfigEntry<float> NoSpawnRadius;
        public static ConfigEntry<float> RaidSpawnMultiplier;
        public static ConfigEntry<string> PeaceMessage;
        public static ConfigEntry<string> BossTrophyBiomeMap;
        public static ConfigEntry<float> ZoneRescanIntervalSeconds;

        public static void Bind(ConfigFile cfg)
        {
            ModEnabled = cfg.Bind(
                "General",
                "ModEnabled",
                true,
                "Master on/off switch for the mod.");

            NoSpawnRadius = cfg.Bind(
                "PeaceZone",
                "NoSpawnRadius",
                500f,
                new ConfigDescription(
                    "Radius (in meters) around a mounted boss trophy within which ambient " +
                    "creature spawning is suppressed for that biome.",
                    new AcceptableValueRange<float>(10f, 1000f)));

            RaidSpawnMultiplier = cfg.Bind(
                "PeaceZone",
                "RaidSpawnMultiplier",
                2f,
                new ConfigDescription(
                    "Multiplier applied to the number of creatures spawned per raid/event " +
                    "creature-spawn call while inside an active peace zone's biome.",
                    new AcceptableValueRange<float>(1.5f, 10f)));

            PeaceMessage = cfg.Bind(
                "General",
                "PeaceMessage",
                "Peace has come!",
                "Center-screen message shown when a boss trophy is mounted on an item stand.");

            ZoneRescanIntervalSeconds = cfg.Bind(
                "Advanced",
                "ZoneRescanIntervalSeconds",
                5f,
                new ConfigDescription(
                    "How often (seconds) the manager re-scans loaded item stands as a safety " +
                    "net in addition to the event-driven attach/detach hooks.",
                    new AcceptableValueRange<float>(1f, 60f)));

            // name:Biome pairs, comma separated. Extend this if new bosses/biomes are added.
            BossTrophyBiomeMap = cfg.Bind(
                "BossTrophies",
                "TrophyToBiomeMap",
                "TrophyEikthyr:Meadows," +
                "TrophyElder:BlackForest," +
                "TrophyBonemass:Swamp," +
                "TrophyModer:Mountain," +
                "TrophyYagluth:Plains," +
                "TrophySeekerQueen:Mistlands," +
                "TrophyFader:AshLands",
                "Maps a boss trophy item's prefab/shared name to the biome its defeat pacifies. " +
                "Format: TrophyPrefabName:BiomeEnumName, comma separated. BiomeEnumName must " +
                "match a value of Heightmap.Biome (e.g. Meadows, BlackForest, Swamp, Mountain, " +
                "Plains, Mistlands, AshLands, DeepNorth, Ocean).");
        }
    }
}

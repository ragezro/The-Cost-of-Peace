using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using ValheimPeaceMod.Patches;

namespace ValheimPeaceMod
{
    [BepInPlugin(PluginGUID, PluginName, PluginVersion)]
    public class Plugin : BaseUnityPlugin
    {
        public const string PluginGUID = "com.yourname.valheimpeacemod";
        public const string PluginName = "ValheimPeaceMod";
        public const string PluginVersion = "1.0.0";

        internal static ManualLogSource Log;

        private Harmony _harmony;
        private RescanTicker _ticker;

        private void Awake()
        {
            Log = Logger;

            Config.Bind(base.Config);
            BossTrophyData.Refresh(Log);

            _harmony = new Harmony(PluginGUID);
            ItemStandPatches.Apply(_harmony, Log);
            SpawnPatches.Apply(_harmony, Log);

            // Small periodic safety-net rescan (belt-and-suspenders alongside
            // the event-driven attach/detach hooks), and the component that
            // keeps the manager alive across scenes.
            _ticker = gameObject.AddComponent<RescanTicker>();

            Log.LogInfo($"[ValheimPeaceMod] Loaded. NoSpawnRadius={Config.NoSpawnRadius.Value}, " +
                        $"RaidSpawnMultiplier={Config.RaidSpawnMultiplier.Value}");
        }

        private void OnDestroy()
        {
            _harmony?.UnpatchSelf();
            PeaceZoneManager.Clear();
        }

        /// <summary>
        /// Tiny MonoBehaviour whose only job is to call the periodic rescan on
        /// an interval and to clear zone state on scene changes (e.g. logging
        /// out / world change), so stale zones from a previous world can't leak
        /// into a new one.
        /// </summary>
        private class RescanTicker : MonoBehaviour
        {
            private float _timer;
            private string _lastScene;

            private void Update()
            {
                if (!Config.ModEnabled.Value) return;
                if (ZNetScene.instance == null) return; // not in-game yet

                var currentScene = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
                if (_lastScene != null && _lastScene != currentScene)
                {
                    PeaceZoneManager.Clear();
                }
                _lastScene = currentScene;

                _timer += Time.deltaTime;
                if (_timer < Mathf.Max(1f, Config.ZoneRescanIntervalSeconds.Value)) return;
                _timer = 0f;

                PeaceZoneManager.RescanLoadedStands(Log);
            }
        }
    }
}

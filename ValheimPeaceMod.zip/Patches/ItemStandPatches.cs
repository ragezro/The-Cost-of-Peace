using System;
using System.Reflection;
using HarmonyLib;

namespace ValheimPeaceMod.Patches
{
    /// <summary>
    /// ItemStand.SetVisualItem(string name, int variant) fires both when an
    /// item is attached AND when it's removed (name == "" on removal). It runs
    /// on every client as part of the stand's ZDO-synced RPC, which is exactly
    /// what we want: every connected player sees the peace message and every
    /// client's local SpawnSystem enforces the peace zone consistently.
    ///
    /// Patches are applied manually (not via [HarmonyPatch] auto-scan) so that
    /// if a method name/signature has changed on your game version, it logs a
    /// clear warning instead of throwing during startup and disabling the mod.
    /// If you see a warning at launch, open assembly_valheim.dll in dnSpy,
    /// find the renamed member on ItemStand, and update the string below.
    /// </summary>
    internal static class ItemStandPatches
    {
        public static void Apply(Harmony harmony, BepInEx.Logging.ManualLogSource log)
        {
            TryPatch(
                harmony, log,
                AccessTools.Method(typeof(ItemStand), "SetVisualItem"),
                postfix: new HarmonyMethod(typeof(ItemStandPatches), nameof(SetVisualItem_Postfix)));

            TryPatch(
                harmony, log,
                AccessTools.Method(typeof(ItemStand), "OnDestroy"),
                prefix: new HarmonyMethod(typeof(ItemStandPatches), nameof(OnDestroy_Prefix)));
        }

        private static void TryPatch(Harmony harmony, BepInEx.Logging.ManualLogSource log,
            MethodBase target, HarmonyMethod prefix = null, HarmonyMethod postfix = null)
        {
            if (target == null)
            {
                log?.LogWarning("[ValheimPeaceMod] Could not find an expected ItemStand method to patch. " +
                                 "Boss-trophy detection may not work - verify against your game version in dnSpy.");
                return;
            }

            try
            {
                harmony.Patch(target, prefix: prefix, postfix: postfix);
            }
            catch (Exception ex)
            {
                log?.LogWarning($"[ValheimPeaceMod] Failed to patch {target.DeclaringType?.Name}.{target.Name}: {ex.Message}");
            }
        }

        private static void SetVisualItem_Postfix(ItemStand __instance, string name, int variant)
        {
            if (!Config.ModEnabled.Value) return;
            if (__instance == null) return;

            var nview = __instance.GetComponent<ZNetView>();
            if (nview == null || !nview.IsValid()) return;

            var standId = nview.GetZDO().m_uid;

            if (string.IsNullOrEmpty(name))
            {
                // Requirement 5: trophy removed -> no-spawn zone ends immediately.
                PeaceZoneManager.UnregisterZone(standId, Plugin.Log);
                return;
            }

            if (!BossTrophyData.TryGetBiome(name, out var biome))
            {
                // Some non-boss item (or a non-mapped trophy) was mounted; ignore.
                return;
            }

            // Requirements 1 & 2: (re)activate the peace zone for this biome.
            // Registering is idempotent, and each stand gets its own zone entry,
            // so this works the same for the first boss defeated or the fifth.
            PeaceZoneManager.RegisterZone(standId, __instance.transform.position, biome, Plugin.Log);

            // Requirement 4: center-screen message.
            if (MessageHud.instance != null)
            {
                MessageHud.instance.ShowMessage(MessageHud.MessageType.Center, Config.PeaceMessage.Value);
            }
        }

        private static void OnDestroy_Prefix(ItemStand __instance)
        {
            if (__instance == null) return;

            var nview = __instance.GetComponent<ZNetView>();
            if (nview == null || !nview.IsValid()) return;

            PeaceZoneManager.UnregisterZone(nview.GetZDO().m_uid, Plugin.Log);
        }
    }
}

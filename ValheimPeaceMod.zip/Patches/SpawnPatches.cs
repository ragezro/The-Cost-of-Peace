using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace ValheimPeaceMod.Patches
{
    /// <summary>
    /// This is the load-bearing patch and the one most likely to need a small
    /// adjustment on your exact game version - VERIFY IN DNSPY FIRST.
    ///
    /// Expected (decompiled) signature, based on Valheim's public event system:
    ///   private bool Spawn(SpawnSystem.SpawnData critter, Vector3Int zoneID,
    ///                       Heightmap heightmap, bool eventCreature = false,
    ///                       ZoneSystem.ZoneVegetation zoneVeg = null)
    ///
    /// SpawnSystem handles BOTH ambient wildlife AND raid/event creatures
    /// through this same method, distinguished by the `eventCreature` flag -
    /// that's what lets a single patch satisfy both requirement 1 (suppress
    /// ambient spawns) and requirement 3 (boost raid spawns) without the two
    /// ever getting confused for each other.
    ///
    /// If dnSpy shows a different signature on your version (extra/missing
    /// params, different param order), update the ParamTypes array below to
    /// match - the Prefix/Postfix bodies use named parameters so as long as
    /// `critter`/`eventCreature`/return type line up the logic itself won't
    /// need to change.
    /// </summary>
    internal static class SpawnPatches
    {
        // Guard against our own re-entrant calls (raid boost re-invoking
        // Spawn) triggering another round of boosting on themselves.
        [ThreadStatic] private static bool _inBoostReentry;

        public static void Apply(Harmony harmony, BepInEx.Logging.ManualLogSource log)
        {
            var method = AccessTools.Method(
                typeof(SpawnSystem),
                "Spawn",
                new[]
                {
                    typeof(SpawnSystem.SpawnData),
                    typeof(Vector3Int),
                    typeof(Heightmap),
                    typeof(bool),
                    typeof(ZoneSystem.ZoneVegetation)
                });

            if (method == null)
            {
                // Fall back to matching by name only, in case default params
                // changed the overload Harmony sees.
                method = AccessTools.Method(typeof(SpawnSystem), "Spawn");
            }

            if (method == null)
            {
                log?.LogError("[ValheimPeaceMod] Could not locate SpawnSystem.Spawn to patch. " +
                               "Ambient no-spawn and raid boost will NOT function. " +
                               "Open assembly_valheim.dll in dnSpy, find SpawnSystem's spawn method, " +
                               "and update Patches/SpawnPatches.cs accordingly.");
                return;
            }

            try
            {
                harmony.Patch(
                    method,
                    prefix: new HarmonyMethod(typeof(SpawnPatches), nameof(Prefix)),
                    postfix: new HarmonyMethod(typeof(SpawnPatches), nameof(Postfix)));
            }
            catch (Exception ex)
            {
                log?.LogError($"[ValheimPeaceMod] Failed to patch SpawnSystem.Spawn: {ex.Message}");
            }
        }

        /// <summary>
        /// Requirement 1/2: cancel ambient (non-event) spawns that fall inside
        /// an active peace zone for their own biome.
        /// </summary>
        private static bool Prefix(SpawnSystem __instance, SpawnSystem.SpawnData critter,
            Vector3Int zoneID, Heightmap heightmap, bool eventCreature, ZoneSystem.ZoneVegetation zoneVeg)
        {
            if (!Config.ModEnabled.Value) return true;
            if (eventCreature) return true;               // never touch raid spawns here
            if (_inBoostReentry) return true;              // safety, shouldn't hit for eventCreature==false

            var pos = ZoneSystemPositionOf(zoneID);
            var biome = WorldGenerator.instance != null
                ? WorldGenerator.instance.GetBiome(pos)
                : heightmap != null ? heightmap.GetBiome(pos) : Heightmap.Biome.None;

            if (PeaceZoneManager.IsPeaceful(pos, biome))
            {
                return false; // skip original Spawn entirely - no creature spawns here
            }

            return true;
        }

        /// <summary>
        /// Requirement 3: after a successful raid/event spawn inside an active
        /// peace zone's biome, re-invoke Spawn extra times to reach the
        /// configured multiplier. Whole extra spawns are applied deterministically;
        /// the fractional remainder is applied probabilistically so the multiplier
        /// holds true on average (e.g. 1.5x = an extra spawn 50% of the time).
        /// </summary>
        private static void Postfix(SpawnSystem __instance, SpawnSystem.SpawnData critter,
            Vector3Int zoneID, Heightmap heightmap, bool eventCreature, ZoneSystem.ZoneVegetation zoneVeg,
            bool __result)
        {
            if (!Config.ModEnabled.Value) return;
            if (!eventCreature) return;
            if (!__result) return;           // original spawn didn't actually happen
            if (_inBoostReentry) return;      // don't let re-invoked calls re-trigger boosting

            var pos = ZoneSystemPositionOf(zoneID);
            var biome = WorldGenerator.instance != null
                ? WorldGenerator.instance.GetBiome(pos)
                : heightmap != null ? heightmap.GetBiome(pos) : Heightmap.Biome.None;

            if (!PeaceZoneManager.IsRaidBoosted(pos, biome)) return;

            var multiplier = Mathf.Clamp(Config.RaidSpawnMultiplier.Value, 1.5f, 10f);
            var extra = multiplier - 1f;               // e.g. 2.0x -> 1 guaranteed extra
            var guaranteedExtra = Mathf.FloorToInt(extra);
            var fractional = extra - guaranteedExtra;   // e.g. 1.5x -> 0 guaranteed, 0.5 chance

            var totalExtra = guaranteedExtra;
            if (UnityEngine.Random.value < fractional)
            {
                totalExtra += 1;
            }

            if (totalExtra <= 0) return;

            var spawnMethod = AccessTools.Method(
                typeof(SpawnSystem),
                "Spawn",
                new[]
                {
                    typeof(SpawnSystem.SpawnData),
                    typeof(Vector3Int),
                    typeof(Heightmap),
                    typeof(bool),
                    typeof(ZoneSystem.ZoneVegetation)
                });

            if (spawnMethod == null) return;

            _inBoostReentry = true;
            try
            {
                for (var i = 0; i < totalExtra; i++)
                {
                    spawnMethod.Invoke(__instance, new object[] { critter, zoneID, heightmap, true, zoneVeg });
                }
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogWarning($"[ValheimPeaceMod] Raid spawn boost re-invocation failed: {ex.Message}");
            }
            finally
            {
                _inBoostReentry = false;
            }
        }

        /// <summary>
        /// SpawnData/zoneID don't directly carry a Vector3 world position in
        /// every game version - some carry it on the SpawnData itself
        /// (critter.m_pos), others derive it from the zone. Try the common
        /// spots and fall back to zone-center math. VERIFY IN DNSPY: if
        /// SpawnSystem.SpawnData has a position field, prefer reading that
        /// directly instead of this helper.
        /// </summary>
        private static Vector3 ZoneSystemPositionOf(Vector3Int zoneID)
        {
            if (ZoneSystem.instance != null)
            {
                return ZoneSystem.instance.GetZonePos(zoneID);
            }

            return new Vector3(zoneID.x * 64f, 0f, zoneID.z * 64f);
        }
    }
}

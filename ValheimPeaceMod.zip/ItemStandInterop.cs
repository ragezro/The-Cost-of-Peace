using System.Reflection;

namespace ValheimPeaceMod
{
    /// <summary>
    /// ItemStand tracks its currently-attached item's shared name internally
    /// and pushes visual/ZDO updates through a method conventionally named
    /// SetVisualItem(string name, int variant) - that's the method
    /// Patches/ItemStandPatches.cs hooks directly for the attach/detach event.
    ///
    /// For the periodic safety-net rescan (PeaceZoneManager.RescanLoadedStands)
    /// we also need to read the CURRENT state of a stand we didn't just see an
    /// event for. Valheim stores this on the stand's ZDO as a string, which is
    /// the most version-stable place to read it from (ZDO keys have been far
    /// more stable across updates than private field names).
    ///
    /// VERIFY: open assembly_valheim.dll in dnSpy and confirm the ZDO string
    /// key ItemStand uses (search for "SetVisualItem" - it will show the ZDO
    /// key it writes, commonly "item"). Adjust ZdoKey below if different.
    /// </summary>
    internal static class ItemStandInterop
    {
        private const string ZdoKey = "item";

        // Fallback via reflection on a private field, only used if the ZDO
        // key above isn't present for some reason (e.g. never-synced stand).
        private static readonly FieldInfo VisualItemField =
            typeof(ItemStand).GetField("m_visualItem", BindingFlags.Instance | BindingFlags.NonPublic);

        public static string GetAttachedItemName(ItemStand stand)
        {
            if (stand == null) return null;

            var nview = stand.GetComponent<ZNetView>();
            if (nview != null && nview.IsValid())
            {
                var zdo = nview.GetZDO();
                var fromZdo = zdo.GetString(ZdoKey, string.Empty);
                if (!string.IsNullOrEmpty(fromZdo))
                {
                    return fromZdo;
                }
            }

            if (VisualItemField != null)
            {
                return VisualItemField.GetValue(stand) as string;
            }

            return null;
        }
    }
}
